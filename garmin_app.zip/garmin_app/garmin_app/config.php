<?php

define('CLIENT_ID', '4f471b13-76ec-4d86-8045-69882a9a6ed3');
define('CLIENT_SECRET', 'h3FaUom20Lr4Ey6JpVBi4RYofiQCCWQUyF2');
define('REDIRECT_URI', 'https://bigdatalab.tau.ac.il/bdl6/garmin_app/callback.php');

?>