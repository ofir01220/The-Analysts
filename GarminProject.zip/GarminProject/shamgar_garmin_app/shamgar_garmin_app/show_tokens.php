<?php
	echo str_replace("\n", "<br>", file_get_contents("tokens.csv"));
?>
