<?php

define('CLIENT_ID', '806457d1-6a09-49ce-8b8b-6004600672ba');
define('CLIENT_SECRET', 'JVjhbomy04DKWtGRdyC9MD0eRNW0JqcbLJS');
define('REDIRECT_URI', 'https://bigdatalab.tau.ac.il/bdl6/shamgar_garmin_app/callback.php');

?>